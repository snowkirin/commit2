<template>
  <div class="zuly-story-about">
    Story About
  </div>
</template>

<script>
export default {
  name: 'story-about',
  components: {
  },
};
</script>

<style scoped>
</style>