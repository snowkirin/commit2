<template>
  <div class="zuly-story-process">
    Story 345345435345345345345
  </div>
</template>

<script>
export default {
  name: 'story-process',
  components: {
  },
};
</script>

<style scoped>
</style>