export const REVERSE_GNB = 'REVERSE_GNB';
export const CLOSE_GNB = 'CLOSE_GNB';
export const SET_STORYVIEW = 'SET_STORYVIEW';
