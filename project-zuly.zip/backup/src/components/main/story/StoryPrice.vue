<template>
  <div class="zuly-story-price">
    Story Price
  </div>
</template>

<script>
export default {
  name: 'story-price',
  components: {
  },
};
</script>

<style scoped>
</style>